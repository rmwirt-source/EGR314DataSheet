# ================= TEAM / TOPICS =================

TEAM = 'EGR314/Team301/MEG'

TOPIC_HB  = TEAM + 'heartbeat'
TOPIC_PUB = TEAM + 'PUB'
TOPIC_SUB = TEAM + 'SUB'

# ================= MQTT =================

MQTT_SERVER   = '34.210.232.255'
MQTT_USER     = 'student'
MQTT_PASSWORD = 'egr3x4'

# ================= WIFI =================

WIFI_SSID     = 'photon'
WIFI_PASSWORD = 'particle'