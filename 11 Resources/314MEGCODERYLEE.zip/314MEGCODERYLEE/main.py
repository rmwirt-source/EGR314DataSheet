from machine import UART, Pin, I2C
import time
import network
import ssl
from umqtt.simple import MQTTClient

# ================= IDs =================
MY_ID = ord('W')
KNOWN_IDS = {ord('W'), ord('B'), ord('T'), ord('F'), ord('H'), ord('E')}

# ================= UART =================
uart = UART(1, 9600, tx=17, rx=16)

# ================= PINS =================
led = Pin(12, Pin.OUT)
button = Pin(15, Pin.IN, Pin.PULL_UP)

boot_btn = Pin(0, Pin.IN, Pin.PULL_UP)
boot_hold_start = None

# ================= WIFI =================
WIFI_SSID = "YOUR_WIFI"
WIFI_PASSWORD = "YOUR_PASSWORD"

# ================= MQTT =================
MQTT_BROKER = "34.210.232.255"
MQTT_PORT = 8883
MQTT_USER = "student"
MQTT_PASS = "egr3x4"

TEAM = "321"
SUB_TOPIC = b"EGR314/Team" + TEAM.encode() + b"/SUB"
PUB_TOPIC = b"EGR314/Team" + TEAM.encode() + b"/PUB"

# ================= I2C =================
i2c = I2C(0, scl=Pin(4), sda=Pin(5))
TC74_ADDR = 0x48

# ================= CONTROL =================
setpoint = 25
temperature = 0
Kp = 5

# ================= PACKET =================
PREFIX = b'AZ'
SUFFIX = b'BY'
FRAME_SIZE = 64
MSG_START = 4
MSG_END = 62

buffer = bytearray()

last_read = time.ticks_ms()
last_send = time.ticks_ms()

# ================= FUNCTIONS =================

def blink(n):
    for _ in range(n):
        led.on()
        time.sleep(0.1)
        led.off()
        time.sleep(0.1)

def safe_exit(msg):
    print(msg)
    led.off()
    time.sleep(1)
    raise SystemExit

def check_failsafe():
    global boot_hold_start
    if boot_btn.value() == 0:
        if boot_hold_start is None:
            boot_hold_start = time.ticks_ms()
        elif time.ticks_diff(time.ticks_ms(), boot_hold_start) > 3000:
            blink(5)
            safe_exit("SAFE MODE")
    else:
        boot_hold_start = None

# ================= WIFI =================
def connect_wifi():
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)

    if not wlan.isconnected():
        print("Connecting WiFi...")
        wlan.connect(WIFI_SSID, WIFI_PASSWORD)

        start = time.time()
        while not wlan.isconnected():
            if time.time() - start > 10:
                print("WiFi failed")
                return None
            time.sleep(0.5)

    print("WiFi OK:", wlan.ifconfig())
    return wlan

# ================= MQTT =================
def mqtt_callback(topic, msg):
    global setpoint

    message = msg.decode().strip()
    print("MQTT:", message)

    if message.endswith(";"):
        message = message[:-1]

    process_message(message)

    # echo back
    mqtt.publish(PUB_TOPIC, (message + ";").encode())

def connect_mqtt():
    ssl_params = {
        "cert": open("student_crt.pem").read(),
        "key": open("student_key.pem").read(),
        "cadata": open("ca_crt.pem").read()
    }

    client = MQTTClient(
        client_id="ESP32_W",
        server=MQTT_BROKER,
        port=MQTT_PORT,
        user=MQTT_USER,
        password=MQTT_PASS,
        ssl=True,
        ssl_params=ssl_params
    )

    client.set_callback(mqtt_callback)
    client.connect()
    client.subscribe(SUB_TOPIC)

    print("MQTT connected")
    return client

# ================= SENSOR =================
def read_temp():
    global temperature, last_read

    if time.ticks_diff(time.ticks_ms(), last_read) > 500:
        last_read = time.ticks_ms()
        try:
            i2c.writeto(TC74_ADDR, b'\x00')
            data = i2c.readfrom(TC74_ADDR, 1)
            temperature = int.from_bytes(data, 'big')
        except:
            temperature = 0

        print("Temp:", temperature)

# ================= CONTROLLER =================
def run_controller():
    global last_send

    if time.ticks_diff(time.ticks_ms(), last_send) < 200:
        return

    last_send = time.ticks_ms()

    error = setpoint - temperature
    output = Kp * error
    speed = int(max(min(output, 255), -255))

    send_packet(ord('B'), "T{}".format(speed))
    send_packet(ord('T'), "T{}".format(speed))

# ================= MESSAGING =================
def build_packet(dst, message=""):
    frame = bytearray(64)
    frame[0:2] = PREFIX
    frame[2] = MY_ID
    frame[3] = dst

    msg_bytes = message.encode()
    frame[MSG_START:MSG_START + len(msg_bytes)] = msg_bytes
    frame[62:64] = SUFFIX
    return frame

def send_packet(dst, msg):
    uart.write(build_packet(dst, msg))

def process_message(msg):
    global setpoint
    try:
        if msg.startswith("S"):
            setpoint = float(msg[1:])
        else:
            setpoint = float(msg)
        print("Setpoint:", setpoint)
    except:
        pass

def handle_packet(pkt):
    if pkt[0:2] != PREFIX or pkt[62:64] != SUFFIX:
        return

    src = pkt[2]
    dst = pkt[3]
    msg = pkt[MSG_START:MSG_END].rstrip(b'\x00').decode()

    if src == MY_ID:
        return

    if dst == MY_ID:
        process_message(msg)

    uart.write(pkt)

# ================= DEBUG =================
def check_button():
    if button.value() == 0:
        time.sleep(0.2)
        send_packet(ord('B'), "T150")
        send_packet(ord('T'), "T150")
        blink(2)

# ================= MAIN =================
print("Starting...")

wlan = connect_wifi()
mqtt = connect_mqtt()

print("Controller running")

while True:
    check_failsafe()

    mqtt.check_msg()

    read_temp()
    run_controller()
    check_button()

    if uart.any():
        data = uart.read(1)
        if data:
            buffer.append(data[0])

            if len(buffer) >= 2 and buffer[0:2] != PREFIX:
                buffer.pop(0)
                continue

            if len(buffer) == FRAME_SIZE:
                handle_packet(buffer)
                buffer = bytearray()

    time.sleep(0.05)